<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\studentcontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
route::get('login', [studentcontroller::class, 'login']);
route::get('index', [studentcontroller::class, 'index']);
 route::get('create', [studentcontroller::class, 'create']);
 route::get('store', [studentcontroller::class, 'store']);
route::get('show{id}', [studentcontroller::class, 'show']);
route::get('edit{id}', [studentcontroller::class, 'edit']);
route::post('update{id}', [studentcontroller::class, 'update']);
route::get('destroy', [studentcontroller::class, 'destroy']);
route::get('logout', [studentcontroller::class, 'logout']);

