
  <div class="row">
      <div class="col-lg-12 margin-tb">
          <div class="pull-left">
              <h2>STUDENT LOGIN PAGE</h2>
          </div>
          <div class="pull-right">
              <a class="btn btn-primary" href="" method="post"> </a>
          </div>
      </div>
  </div>
     

     
  <form action="create" method="post">
      {{ csrf_field() }}
    
       <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12">
              <div class="form-group">
                  <strong>Name</strong>
                  <input type="text"  class="form-control" placeholder="Name"><br><br>
              </div>
          </div>
        
          <div class="col-xs-12 col-sm-12 col-md-12">
              <div class="form-group">
                  <strong>password</strong>
                  <input type="text" class="form-control"  placeholder="password"><br><br>
              </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                  <button type="submit" class="btn btn-primary">Submit</button>
          </div>
      </div>
     
  </form>
