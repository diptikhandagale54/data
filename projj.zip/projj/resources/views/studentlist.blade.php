<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}


</style>
<title>SCHOOL MANAGEMENT</title>
</head>
<body>
@foreach($students as student)
<tr>
<td>{{student->id}}</td>
<td>{{student->fname}}</td>
<td>{{student->lname}}</td>
<td>{{student->age}}</td>
<td>{{student->speciality}}</td>
<td><a href="#" class="btn btn-sm btn-info">show</a>
<td><a href="{{url('/edit'}}" class="btn btn-sm-btn-warning">edit</a>



</tr>
<h2></h2>

<table>
  <tr>
    <th>id</th>
    <th>fname</th>
    <th>lname</th>
    <th>age</th>
    <th>speciality</th>

   </tr>

 
</table>

</body>
</html>

