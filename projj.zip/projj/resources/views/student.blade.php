<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-uWxY/CJNBR+1zjPWmfnSnVxwRheevXITnMqoEIeG1LJrdI0GlVs/9cVSyPYXdcSF" crossorigin="anonymous">


  </head>
  <body>
  if ($layout =='index')
<div>class='continer-fluid'>
<div>class='row'>

<section class="col">@include("studentlist")
</section>
<section class="col"></section></div></div>

@elseif($layout=='create')
<div>class='continer-fluid'>
<div>class='row'>

<section class="col">@include("studentlist")
</section>
<section class="col">
    <form action="{{url('/store')}}"   method="post">
    @csrf
<div class="mb-3">
  <label>id</label>
  <input name="id" type="text" class="form-control" placeholder="entr the id">
</div>
<div class="mb-3">
  <label>fname</label>
  <input name="fname" type="text" class="form-control" placeholder="entr the first name">
</div><div class="mb-3">
  <label>lname</label>
  <input name="lname" type="text" class="form-control" placeholder="entr the last name">
</div><div class="mb-3">
  <label>age</label>
  <input name="age" type="text" class="form-control" placeholder="entr the age">
</div><div class="mb-3">
  <label>speciality</label>
  <input names="speciality" type="text" class="form-control" placeholder="entr the speciality">
</div>
<input type="submit" class="btn-btn-info" value="save">
<input type="reseT" class="btn-btn-warning" value="reset">

</form>
</section></div></div>

elseif($layout=='show')
<div>class='continer-fluid'>
<div>class='row'>

<section class="col">@include("studentlist")
</section>
<section class="col"></section>
</div></div>


@elseif($layout=='edit')
<div class="continer-fluid mt-4">
<div>class="row">
<section class="col md-7">
    @include("studentlist")
</section>
<section class="col md-5">
<form action="{{url('/update/'.$student->id}}" method="post">
@csrf
<div class="form group">
<label>id</label>
  <input value="{{student->id}}" name="id" type="text" class="form-control" placeholder="id">
</div>
<div class="form group">
<label>fname</label>
  <input value="{{student->fname}}" name="fname" type="text" class="form-control" placeholder="entr the first name">
</div>
<div class="form group">
<label>lname</label>
  <input value="{{student->lname}}" name="lname" type="text" class="form-control" placeholder="entr the first name">
</div><div class="form group">
<label>age</label>
  <input value="{{student->age}}" name="age" type="text" class="form-control" placeholder="entr the first age">
</div>
<div class="form group">
<label>speciality</label>
  <input value="{{student->speciality}}" name="speciality" type="text" class="form-control" placeholder=speciality>
</div>
</section>
</div></div>
@endif

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-kQtW33rZJAHjgefvhyyzcGF3C5TFyBQBA13V1RKPf4uH+bwyzQxZ6CmMZHmNBEfJ" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.min.js" integrity="sha384-PsUw7Xwds7x08Ew3exXhqzbhuEYmA2xnwc8BuD6SEr+UmEHlX8/MCltYEodzWA4u" crossorigin="anonymous"></script>
    -->
  </body>
</html>

















