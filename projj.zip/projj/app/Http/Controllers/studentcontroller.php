<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\student;
class studentcontroller extends Controller
{
    public function login(Request $request)
    {
        $student_data = array(
        'email' => $request->get('email'),
        'password' => $request->get('password'),
        );

    
        if(student::guard('student')->attempt($student_data))
        {   
            return redirect('create');
        }
        else{
          return redirect('index')->with('errorMsg', 'Invalid ');
        }
  
    }
        
    function index(Request $request)
        {
            $student=student::all();
            return view('student',['students'=>$students,'layout'=>'index']);
        }
    
    
        function create(Request $request)
        {
            $student=student::all();
            return view('student',['students'=>$students,'layout'=>'create']);
        }
    
    
        public function store(Request $request)
      {
    $student=new student();
    $student->id=$request->input('id');
    $student->firstname=$request->input('firstname');
    $student->lastname=$request->input('lastname');
    $student->age=$request->input('age');
    $student->speciality=$request->input('speciality');
    $student=save();
    return redirect('/');
      }
    public function show($id)
    {
        $student=student::find($id);
        return view('student',['students'=>$students,'student'=>$student,'layout'=>'show']);
    }
    public function edit($id)
    {
        $student=student::find($id);
        $student=student::all();
    
        return view('student',['students'=>$students,'student'=>$student,'layout'=>'edit']);
    }
    public function update(request $request ,$id)
     {
        $student->id=$request->input('id');
        $student->firstname=$request->input('firstname');
        $student->lastname=$request->input('lastname');
        $student->age=$request->input('age');
        $student->speciality=$request->input('speciality');
        $student=save();
        return redirect('/');
     }
     public function destroy($id)
    {
        $student=student::find($id);
        $student->delete();
        return redirect('/');
    }
    public function logout() {
        if (Auth::guard('student')->check()) {
            Session::flush();
            Auth::logout();
            return redirect('index')->with('success_msg', 'logout successfully');
        } else {
            return redirect('index');
        }

    }
} 